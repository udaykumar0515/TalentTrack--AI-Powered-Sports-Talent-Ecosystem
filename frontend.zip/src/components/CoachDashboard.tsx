import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { postCoachAction } from '../api/apiClient';

const CoachDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [sessions, setSessions] = useState<any[]>([]);
  const [filterAthlete, setFilterAthlete] = useState('');

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      // Load sessions from localStorage where coachId matches current coach
      const allSessions: any[] = [];
      const keys = Object.keys(localStorage);
      
      for (const key of keys) {
        if (key.startsWith('sessions_')) {
          try {
            const userSessions = JSON.parse(localStorage.getItem(key) || '[]');
            const coachSessions = userSessions.filter((session: any) => 
              session.coachId === user?.id
            );
            allSessions.push(...coachSessions);
          } catch (error) {
            console.error('Error parsing sessions for key:', key, error);
          }
        }
      }
      
      setSessions(allSessions);
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
      setSessions([]);
    }
  };

  const handleRequestRetest = async (sessionId: string, athleteId: string) => {
    try {
      await postCoachAction({
        type: 'retest',
        athleteId,
        sessionId,
        reason: 'Coach requested re-examination',
        notes: 'Please redo the exercise for better analysis'
      });
      alert('Retest request sent to athlete!');
    } catch (error) {
      console.error('Failed to send retest request:', error);
      alert('Retest request sent! (Demo mode)');
    }
  };

  const handleSendFeedback = async (sessionId: string, athleteId: string) => {
    const feedback = prompt('Enter your feedback:');
    if (!feedback) return;

    try {
      await postCoachAction({
        type: 'feedback',
        athleteId,
        sessionId,
        notes: feedback
      });
      alert('Feedback sent to athlete!');
    } catch (error) {
      console.error('Failed to send feedback:', error);
      alert('Feedback sent! (Demo mode)');
    }
  };

  const handleViewSession = (sessionId: string) => {
    navigate(`/session/${sessionId}`);
  };

  const getRiskClass = (risk: string) => {
    return risk.toLowerCase();
  };

  const filteredSessions = sessions.filter(session => 
    session.athleteName.toLowerCase().includes(filterAthlete.toLowerCase()) ||
    session.exercise.toLowerCase().includes(filterAthlete.toLowerCase())
  );

  // Sample data for demo
  const sampleSessionData = [
    { 
      sessionId: 'sess_001',
      athleteId: 'athlete1',
      athleteName: 'John Doe', 
      exercise: 'Squats', 
      reps: 15, 
      score: 92, 
      risk: 'Low', 
      date: '2025-01-15',
      metrics: { reps: 15, formScore: 92 }
    },
    { 
      sessionId: 'sess_002',
      athleteId: 'athlete2',
      athleteName: 'Jane Smith', 
      exercise: 'Jumping Jacks', 
      duration: '1:30', 
      score: 75, 
      risk: 'Medium', 
      date: '2025-01-14',
      metrics: { formScore: 75 }
    },
    { 
      sessionId: 'sess_003',
      athleteId: 'athlete3',
      athleteName: 'Peter Jones', 
      exercise: 'Push-ups', 
      reps: 20, 
      score: 55, 
      risk: 'High', 
      date: '2025-01-13',
      metrics: { reps: 20, formScore: 55 }
    }
  ];

  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        <div className="header-left">
          <h1>Coach Dashboard</h1>
          <p>Welcome, {user?.username}!</p>
        </div>
        <div className="header-right">
          <button onClick={logout} className="logout-btn">
            Logout
          </button>
        </div>
        <div className="filters">
          <input
            type="text"
            id="filter-athlete"
            placeholder="Filter by athlete name or exercise"
            value={filterAthlete}
            onChange={(e) => setFilterAthlete(e.target.value)}
          />
        </div>
      </header>

      <section className="athlete-table-section">
        <h2>Athlete Performance</h2>
        <div className="table-scroll">
          <table id="performance-table">
            <thead>
              <tr>
                <th>Athlete Name</th>
                <th>Exercise Type</th>
                <th>Reps / Duration</th>
                <th>Performance Score</th>
                <th>Injury Risk</th>
                <th>Last Activity Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredSessions.map((session) => (
                <tr key={session.sessionId}>
                  <td>{session.athleteName}</td>
                  <td>{session.exercise}</td>
                  <td>{session.reps || session.duration}</td>
                  <td>{session.score}</td>
                  <td>
                    <span className={`risk-level ${getRiskClass(session.risk)}`}>
                      {session.risk}
                    </span>
                  </td>
                  <td>{session.date}</td>
                  <td>
                    <button
                      className="action-btn retest-btn"
                      onClick={() => handleRequestRetest(session.sessionId, session.athleteId)}
                    >
                      Request Retest
                    </button>
                    <button
                      className="action-btn feedback-btn"
                      onClick={() => handleSendFeedback(session.sessionId, session.athleteId)}
                    >
                      Send Feedback
                    </button>
                    <button
                      className="action-btn"
                      onClick={() => handleViewSession(session.sessionId)}
                    >
                      View Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};

export default CoachDashboard;