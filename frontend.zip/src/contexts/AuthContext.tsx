import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Coach } from './CoachContext';

export interface User {
  id: string;
  email: string;
  username: string;
  role: 'athlete' | 'coach';
  createdAt: string;
}

export interface AuthContextType {
  user: User | null;
  login: (email: string, password: string, expectedRole?: 'athlete' | 'coach') => Promise<boolean>;
  register: (email: string, password: string, username: string, role: 'athlete' | 'coach') => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
  error: string | null;
  getAllUsers: () => { athletes: User[], coaches: User[] };
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

    // Function to read data from JSON files
    const readJSONFile = async (filename: string): Promise<any[]> => {
      try {
        const response = await fetch(`/${filename}`);
        if (response.ok) {
          return await response.json();
        }
        return [];
      } catch (error) {
        console.error(`Error reading ${filename}:`, error);
        return [];
      }
    };
  
    // Function to write data to JSON files
    const writeJSONFile = async (filename: string, data: any[]): Promise<boolean> => {
      try {
        // In a real application, you would send this to your backend
        // For now, we'll simulate by storing in localStorage as a fallback
        localStorage.setItem(filename, JSON.stringify(data));
        return true;
      } catch (error) {
        console.error(`Error writing to ${filename}:`, error);
        return false;
      }
    };
  // Enhanced function to ensure data persistence
  const ensureDataPersistence = async () => {
    try {
      // Initialize athletes if not present
      let athletesInStorage = localStorage.getItem('athletes');
      if (!athletesInStorage) {
        console.log('Loading athletes from JSON file...');
        try {
          const response = await fetch('/src/athletes.json');
          if (response.ok) {
            const athletesFromFile = await response.json();
            localStorage.setItem('athletes', JSON.stringify(athletesFromFile));
            console.log('Athletes loaded and stored in localStorage');
          } else {
            // If file doesn't exist, initialize with empty array
            localStorage.setItem('athletes', JSON.stringify([]));
            console.log('Initialized empty athletes array');
          }
        } catch (fetchError) {
          console.warn('Could not fetch athletes.json, initializing empty array:', fetchError);
          localStorage.setItem('athletes', JSON.stringify([]));
        }
      } else {
        console.log('Athletes already exist in localStorage');
      }

      // Initialize coaches if not present
      let coachesInStorage = localStorage.getItem('coaches');
      if (!coachesInStorage) {
        console.log('Loading coaches from JSON file...');
        try {
          const response = await fetch('/src/coaches.json');
          if (response.ok) {
            const coachesFromFile = await response.json();
            localStorage.setItem('coaches', JSON.stringify(coachesFromFile));
            console.log('Coaches loaded and stored in localStorage');
          } else {
            // If file doesn't exist, initialize with empty array
            localStorage.setItem('coaches', JSON.stringify([]));
            console.log('Initialized empty coaches array');
          }
        } catch (fetchError) {
          console.warn('Could not fetch coaches.json, initializing empty array:', fetchError);
          localStorage.setItem('coaches', JSON.stringify([]));
        }
      } else {
        console.log('Coaches already exist in localStorage');
      }

      // Validate and clean up data integrity
      const athletes = JSON.parse(localStorage.getItem('athletes') || '[]');
      const coaches = JSON.parse(localStorage.getItem('coaches') || '[]');
      
      // Ensure arrays are valid
      if (!Array.isArray(athletes)) {
        localStorage.setItem('athletes', JSON.stringify([]));
      }
      if (!Array.isArray(coaches)) {
        localStorage.setItem('coaches', JSON.stringify([]));
      }

      console.log(`Total users in storage - Athletes: ${athletes.length}, Coaches: ${coaches.length}`);
      
    } catch (error) {
      console.error('Error ensuring data persistence:', error);
      // Fallback: ensure at least empty arrays exist
      if (!localStorage.getItem('athletes')) {
        localStorage.setItem('athletes', JSON.stringify([]));
      }
      if (!localStorage.getItem('coaches')) {
        localStorage.setItem('coaches', JSON.stringify([]));
      }
    }
  };

  // Load user from localStorage on mount and ensure data persistence
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        // Ensure all user data is properly stored
        await ensureDataPersistence();
        
        // Load current user session
        const storedUser = localStorage.getItem('user');
        if (storedUser) {
          const userData = JSON.parse(storedUser);
          // Verify user still exists in the respective storage
          const userKey = userData.role === 'coach' ? 'coaches' : 'athletes';
          const users = JSON.parse(localStorage.getItem(userKey) || '[]');
          const userExists = users.find((u: any) => u.id === userData.id);
          
          if (userExists) {
            setUser(userData);
            console.log('User session restored:', userData.email);
          } else {
            // User no longer exists, clear session
            localStorage.removeItem('user');
            console.log('User session cleared - user no longer exists');
          }
        }
      } catch (error) {
        console.error('Error initializing auth:', error);
        localStorage.removeItem('user');
      } finally {
        setIsLoading(false);
      }
    };
    
    initializeAuth();
  }, []);
const login = async (email: string, password: string, expectedRole?: 'athlete' | 'coach'): Promise<boolean> => {
  setIsLoading(true);
  setError(null);

  try {
    const response = await fetch('http://localhost:3001/api/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email,
        password,
        role: expectedRole
      }),
    });

    if (response.ok) {
      const user = await response.json();
      setUser(user);
      localStorage.setItem('user', JSON.stringify(user));
      return true;
    } else {
      const errorData = await response.json();
      setError(errorData.error || 'Login failed');
      return false;
    }
  } catch (error) {
    console.error('Login error:', error);
    setError('Login failed. Please try again.');
    return false;
  } finally {
    setIsLoading(false);
  }
};

  // Modified register function
  const register = async (email: string, password: string, username: string, role: 'athlete' | 'coach'): Promise<boolean> => {
    setIsLoading(true);
    setError(null);

    try {
      const filename = role === 'coach' ? 'coaches.json' : 'athletes.json';
      const users = await readJSONFile(filename);
      
      // Check if user already exists
      const existingUser = users.find((u: any) => u.email === email);
      if (existingUser) {
        setError('User with this email already exists');
        return false;
      }
      
      // Create new user
      const newUser = {
        id: generateId(),
        email,
        password,
        username,
        role,
        createdAt: new Date().toISOString()
      };
      
      // Add user to appropriate list
      users.push(newUser);
      const success = await writeJSONFile(filename, users);
      
      if (!success) {
        setError('Registration failed. Please try again.');
        return false;
      }
      
      // Auto-login after registration
      const { password: _, ...userWithoutPassword } = newUser;
      setUser(userWithoutPassword);
      localStorage.setItem('user', JSON.stringify(userWithoutPassword));
      
      return true;
    } catch (error) {
      console.error('Registration error:', error);
      setError('Registration failed. Please try again.');
      return false;
    } finally {
      setIsLoading(false);
    }
  };
  
  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
    console.log('User logged out');
  };

  // Function to get all users (useful for debugging and admin purposes)
  const getAllUsers = () => {
    const athletes = JSON.parse(localStorage.getItem('athletes') || '[]');
    const coaches = JSON.parse(localStorage.getItem('coaches') || '[]');
    
    // Remove passwords from the returned data for security
    const athletesWithoutPasswords = athletes.map(({ password, ...user }: any) => user);
    const coachesWithoutPasswords = coaches.map(({ password, ...user }: any) => user);
    
    return {
      athletes: athletesWithoutPasswords,
      coaches: coachesWithoutPasswords
    };
  };

  const generateId = (): string => {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  };

  const value: AuthContextType = {
    user,
    login,
    register,
    logout,
    isLoading,
    error,
    getAllUsers
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
