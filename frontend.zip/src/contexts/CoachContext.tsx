import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface Coach {
  id: string;
  email: string;
  username: string;
  createdAt: string;
}

export interface CoachContextType {
  coaches: Coach[];
  addCoach: (coach: Coach) => void;
  getCoachById: (id: string) => Coach | undefined;
  isLoading: boolean;
}

const CoachContext = createContext<CoachContextType | undefined>(undefined);

export const useCoaches = () => {
  const context = useContext(CoachContext);
  if (context === undefined) {
    throw new Error('useCoaches must be used within a CoachProvider');
  }
  return context;
};

interface CoachProviderProps {
  children: ReactNode;
}


export const CoachProvider: React.FC<CoachProviderProps> = ({ children }) => {
  const [coaches, setCoaches] = useState<Coach[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Load coaches from JSON file on mount
  useEffect(() => {
    loadCoaches();
  }, []);

  const loadCoaches = async () => {
    try {
      setIsLoading(true);
      const response = await fetch('/coaches.json');
      if (response.ok) {
        const coachesData = await response.json();
        setCoaches(coachesData);
      } else {
        console.error('Failed to load coaches');
      }
    } catch (error) {
      console.error('Error loading coaches:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const addCoach = (coach: Coach) => {
    setCoaches(prevCoaches => {
      const updatedCoaches = [...prevCoaches, coach];
      // Also update the JSON file
      fetch('/coaches.json', {
        method: 'PUT', // Note: This won't work for static files
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatedCoaches),
      }).catch(error => {
        console.error('Error updating coaches.json:', error);
      });
      return updatedCoaches;
    });
  };

  const getCoachById = (id: string): Coach | undefined => {
    return coaches.find(coach => coach.id === id);
  };

  return (
    <CoachContext.Provider value={{
      coaches,
      addCoach,
      getCoachById,
      isLoading
    }}>
      {children}
    </CoachContext.Provider>
  );
};
