# main.py
from fastapi import FastAPI, HTTPException, Depends, status, BackgroundTasks ,UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import shutil
import tempfile
import json
import uuid
from datetime import datetime
import subprocess
import threading
import time
from fastapi.staticfiles import StaticFiles
import os, uuid, shutil, asyncio, logging
import hashlib

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# User models
class UserCreate(BaseModel):
    email: str
    password: str
    username: str
    role: str

class UserLogin(BaseModel):
    email: str
    password: str
    role: Optional[str] = None

class User(BaseModel):
    id: str
    email: str
    username: str
    role: str
    created_at: str

class AnalysisRequest(BaseModel):
    exercise: str
    userId: str
    userName: str
    coachId: Optional[str] = None
    coachName: Optional[str] = None

class SessionResult(BaseModel):
    exercise: str
    reps: int
    formScore: int
    durationSec: float
    timestamp: str
    athleteId: str
    athleteName: str
    coachId: Optional[str] = None
    coachName: Optional[str] = None

app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],  # Added more common dev ports
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global state for exercise analysis
current_process = None
analysis_results = {}

# Initialize data directories
def init_data_directories():
    """Ensure all required data directories exist"""
    directories = ["data", "data/sessions"]
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
    
    # Initialize empty JSON files if they don't exist
    files = ["data/athletes.json", "data/coaches.json", "data/sessions/sessions.json"]
    for file_path in files:
        if not os.path.exists(file_path):
            if file_path.endswith("sessions.json"):
                with open(file_path, "w") as f:
                    json.dump({}, f)
            else:
                with open(file_path, "w") as f:
                    json.dump([], f)

# Initialize on startup
init_data_directories()

def hash_password(password: str) -> str:
    """Hash password using SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(password: str, hashed_password: str) -> bool:
    """Verify password against hash"""
    return hash_password(password) == hashed_password

# Helper functions
def read_json_file(filename: str):
    try:
        file_path = f"data/{filename}"
        if not os.path.exists(file_path):
            logger.warning(f"File {file_path} not found, returning empty list")
            return []
        with open(file_path, "r") as file:
            return json.load(file)
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in {filename}: {e}")
        return []
    except Exception as e:
        logger.error(f"Error reading {filename}: {e}")
        return []

def write_json_file(filename: str, data: list):
    try:
        file_path = f"data/{filename}"
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, "w") as file:
            json.dump(data, file, indent=2)
    except Exception as e:
        logger.error(f"Error writing {filename}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to save data: {str(e)}")

def save_session_result(session_data: Dict[str, Any]):
    """Save session result to JSON file"""
    try:
        # Create sessions directory if it doesn't exist
        os.makedirs("data/sessions", exist_ok=True)
        
        # Load existing sessions or create new dict
        sessions_file = "data/sessions/sessions.json"
        if os.path.exists(sessions_file):
            with open(sessions_file, "r") as f:
                content = f.read().strip()
                sessions = json.loads(content) if content else {}
        else:
            sessions = {}
        
        # Add session to user's session list
        user_id = session_data["athleteId"]
        if user_id not in sessions:
            sessions[user_id] = {"sessions": []}
        
        sessions[user_id]["sessions"].append(session_data)
        
        # Save back to file
        with open(sessions_file, "w") as f:
            json.dump(sessions, f, indent=2)
            
        logger.info(f"Session saved for user {user_id}")
        return True
    except Exception as e:
        logger.error(f"Error saving session: {e}")
        return False

def terminate_process_safely(process):
    """Safely terminate a subprocess"""
    if process and process.poll() is None:
        try:
            process.terminate()
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            logger.warning("Process didn't terminate gracefully, killing it")
            process.kill()
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                logger.error("Failed to kill process")

@app.get("/api/coaches", response_model=List[User])
async def get_coaches():
    coaches = read_json_file("coaches.json")
    # Return coaches without passwords
    return [{k: v for k, v in coach.items() if k != "password"} for coach in coaches]

# Authentication endpoints
@app.post("/api/register", response_model=User)
async def register(user_data: UserCreate):
    try:
        # Determine which file to use based on role
        filename = "coaches.json" if user_data.role == "coach" else "athletes.json"
        users = read_json_file(filename)
        
        # Check if user already exists
        if any(user["email"] == user_data.email for user in users):
            raise HTTPException(status_code=400, detail="Email already registered")
        
        # Create new user with hashed password
        new_user = {
            "id": str(uuid.uuid4()),
            "email": user_data.email,
            "password": hash_password(user_data.password),  # Hash the password
            "username": user_data.username,
            "role": user_data.role,
            "created_at": datetime.now().isoformat()
        }
        
        users.append(new_user)
        write_json_file(filename, users)
        
        logger.info(f"New {user_data.role} registered: {user_data.email}")
        
        # Return user without password
        return {k: v for k, v in new_user.items() if k != "password"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Registration error: {e}")
        raise HTTPException(status_code=500, detail="Registration failed")

@app.post("/api/login", response_model=User)
async def login(login_data: UserLogin):
    try:
        # Check both athletes and coaches
        athletes = read_json_file("athletes.json")
        coaches = read_json_file("coaches.json")
        all_users = athletes + coaches
        
        # Find user by email
        user = next((u for u in all_users if u["email"] == login_data.email), None)
        if not user or not verify_password(login_data.password, user["password"]):
            raise HTTPException(status_code=401, detail="Invalid credentials")
        
        # Check role if specified
        if login_data.role and user["role"] != login_data.role:
            raise HTTPException(status_code=403, detail=f"User is not a {login_data.role}")
        
        logger.info(f"User logged in: {login_data.email}")
        
        # Return user without password
        return {k: v for k, v in user.items() if k != "password"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Login error: {e}")
        raise HTTPException(status_code=500, detail="Login failed")

# Exercise analysis endpoints
@app.post("/api/start-analysis")
async def start_analysis(request: AnalysisRequest, background_tasks: BackgroundTasks):
    global current_process
    
    try:
        # Stop any existing analysis
        terminate_process_safely(current_process)
        
        # Prepare command for exercise counter
        exercise_mapping = {
            "squat": "squat",
            "pushup": "pushups", 
            "jumping_jack": "jumping_jacks"
        }
        
        python_exercise = exercise_mapping.get(request.exercise, request.exercise)
        
        # Check if exercise counter script exists
        if not os.path.exists("exercise_counter.py"):
            raise HTTPException(status_code=500, detail="Exercise counter script not found")
        
        # Run exercise counter in background
        def run_exercise_counter():
            global current_process
            try:
                cmd = [
                    "python", "exercise_counter.py",
                    "--user-id", request.userId,
                    "--user-name", request.userName,
                    "--exercise", python_exercise
                ]
                
                if request.coachId:
                    cmd.extend(["--coach-id", request.coachId])
                if request.coachName:
                    cmd.extend(["--coach-name", request.coachName])
                
                logger.info(f"Starting exercise analysis for user {request.userId}")
                
                current_process = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
                
                # Add timeout to prevent hanging
                try:
                    stdout, stderr = current_process.communicate(timeout=300)  # 5 minute timeout
                except subprocess.TimeoutExpired:
                    logger.error("Exercise counter timed out")
                    terminate_process_safely(current_process)
                    return
                
                if current_process.returncode == 0 and stdout:
                    try:
                        result = json.loads(stdout.strip())
                        analysis_results[request.userId] = result
                        
                        # Convert to frontend format and save
                        session_data = {
                            "exercise": request.exercise,
                            "reps": result.get("reps", 0),
                            "formScore": result.get("formScore", 0),
                            "durationSec": result.get("durationSec", 0),
                            "timestamp": datetime.now().isoformat() + "Z",
                            "athleteId": request.userId,
                            "athleteName": request.userName,
                            "coachId": request.coachId,
                            "coachName": request.coachName
                        }
                        
                        save_session_result(session_data)
                        logger.info(f"Analysis completed for user {request.userId}")
                        
                    except json.JSONDecodeError as e:
                        logger.error(f"Failed to parse exercise counter output: {stdout}, error: {e}")
                else:
                    logger.error(f"Exercise counter failed with return code {current_process.returncode}")
                
                if stderr:
                    logger.error(f"Exercise counter error: {stderr}")
                    
            except Exception as e:
                logger.error(f"Error running exercise counter: {e}")
            finally:
                current_process = None
        
        background_tasks.add_task(run_exercise_counter)
        
        return {"status": "started", "message": "Exercise analysis started"}
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error starting analysis: {e}")
        raise HTTPException(status_code=500, detail="Failed to start analysis")

@app.get("/api/analysis-status/{user_id}")
async def get_analysis_status(user_id: str):
    try:
        if user_id in analysis_results:
            return {"status": "completed", "result": analysis_results[user_id]}
        return {"status": "processing", "message": "Analysis in progress"}
    except Exception as e:
        logger.error(f"Error getting analysis status: {e}")
        raise HTTPException(status_code=500, detail="Failed to get analysis status")

@app.post("/api/stop-analysis")
async def stop_analysis():
    global current_process
    
    try:
        if current_process and current_process.poll() is None:
            terminate_process_safely(current_process)
            current_process = None
            logger.info("Analysis stopped by user")
            return {"status": "stopped", "message": "Analysis stopped"}
        
        return {"status": "inactive", "message": "No active analysis"}
    except Exception as e:
        logger.error(f"Error stopping analysis: {e}")
        raise HTTPException(status_code=500, detail="Failed to stop analysis")

@app.get("/api/user-sessions/{user_id}")
async def get_user_sessions(user_id: str):
    """Get all sessions for a specific user"""
    try:
        sessions_file = "data/sessions/sessions.json"
        if os.path.exists(sessions_file):
            with open(sessions_file, "r") as f:
                content = f.read().strip()
                sessions = json.loads(content) if content else {}
                user_sessions = sessions.get(user_id, {}).get("sessions", [])
                return user_sessions
        return []
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in sessions file: {e}")
        raise HTTPException(status_code=500, detail="Corrupted session data")
    except Exception as e:
        logger.error(f"Error loading sessions: {e}")
        raise HTTPException(status_code=500, detail=f"Error loading sessions: {str(e)}")
# inside main.py -> update analyze_video endpoint implementation
@app.post("/api/analyze")
async def analyze_video(
    file: UploadFile = File(...),
    exercise: str = Form(...),
    athleteId: str = Form(...)
):
    temp_file_path = None
    try:
        if not file.content_type.startswith('video/'):
            raise HTTPException(status_code=400, detail="File must be a video")
        if not os.path.exists("exercise_counter.py"):
            raise HTTPException(status_code=500, detail="Exercise counter script not found")

        # Save uploaded file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as temp_file:
            shutil.copyfileobj(file.file, temp_file)
            temp_file_path = temp_file.name

        logger.info(f"Saved uploaded video to {temp_file_path} for athlete {athleteId}")

        # normalize exercise names (map frontend -> script expected)
        exercise_map = {
            "squat": "squat",
            "pushup": "pushups", "pushups": "pushups",
            "jumping_jack": "jumping_jacks", "jumping_jacks": "jumping_jacks"
        }
        exercise_internal = exercise_map.get(exercise, exercise)

        process = subprocess.Popen([
            PYTHON_EXECUTABLE, "exercise_counter.py",
            "--user-id", athleteId,
            "--user-name", "Athlete",
            "--exercise", exercise_internal,
            "--video-file", temp_file_path
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        try:
            stdout, stderr = process.communicate(timeout=300)  # 5 minute timeout
        except subprocess.TimeoutExpired:
            process.kill()
            raise HTTPException(status_code=500, detail="Video analysis timed out")

        if stderr:
            # log analyzer stderr (useful to debug)
            logger.info(f"Analyzer stderr: {stderr.strip()}")

        if process.returncode != 0:
            logger.error(f"Analyzer failed (code {process.returncode}) stderror: {stderr.strip()}")
            raise HTTPException(status_code=500, detail=f"Analysis failed: {stderr.strip()}")

        # try to parse stdout JSON
        try:
            parsed = json.loads(stdout.strip())
        except Exception:
            # fallback: find last JSON object substring in stdout
            last_open = stdout.rfind('{')
            last_close = stdout.rfind('}')
            if last_open != -1 and last_close != -1 and last_close > last_open:
                snippet = stdout[last_open:last_close+1]
                try:
                    parsed = json.loads(snippet)
                except Exception as e:
                    logger.error(f"Failed to parse JSON from analyzer stdout snippet: {e}; stdout:\n{stdout}")
                    raise HTTPException(status_code=500, detail="Failed to parse analysis result")
            else:
                logger.error(f"No JSON found in analyzer stdout; stdout:\n{stdout}")
                raise HTTPException(status_code=500, detail="Failed to parse analysis result")

        # Construct session data for frontend & storage
        session_data = {
            "exercise": exercise,
            "reps": parsed.get("reps", 0),
            "formScore": parsed.get("formScore", 0),
            "durationSec": parsed.get("durationSec", 0),
            "timestamp": datetime.now().isoformat() + "Z",
            "athleteId": athleteId,
            "athleteName": parsed.get("userName", "Athlete"),
            "coachId": None,
            "coachName": None
        }

        save_session_result(session_data)
        logger.info(f"Video analysis completed for athlete {athleteId}")

        return session_data

    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Error in video analysis")
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")
    finally:
        if temp_file_path and os.path.exists(temp_file_path):
            try:
                os.unlink(temp_file_path)
            except Exception:
                logger.warning("Could not remove temp file")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)